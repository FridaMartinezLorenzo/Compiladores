public class prueba4 {
    public static void main(string[] args) {
       int x, y;
       float z = 1.1, k;
       int a = 1, b= 2;
       char c;
       char d = 'a';
       string s = "hola";
       boolean b = true;
       public static int count = 0;
       system.out.println("Hola mundo");
       printf("Hola mundo");
    }
    public void Animal(){
       int age;
    }

}
