public class prueba1 {
    public static void saludar() {
        system.out.println("Hola, mundo");
       int a = 5;
    }

    
    public static void main(string[] args) {
       float b = 6.12345633f;
    }
}
