public class prueba5 {
    public static void main(string[] args) {
       int x, y;
       float z = 1.1, k;
       int a = 1, b= 2;
       char c;
       char d = 'a';
       string s = "hola";
       boolean b = true;
       public static int count = 0;
       a = a+1;
       a = a+b;
       int k = 1+3;
       int j = a+b;
       int l = a*8;
       if(a == 1){
       }
       for(int i = 0; i < 10; i++){
       }
       while (a < 10) {
       }
       do {
       } while (a < 10);

       switch (a) {
        case 1:
            
            break;
        
        case 2:
            
            break;
        default:
            
            break;
       }

       return a;
    }

}

