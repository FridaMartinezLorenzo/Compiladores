
public class prueba3 {
    int suma(string[] args) {
       int x, y;
       float z = 1.1;
       int a = 1;
    }
}
class Animal {

}
