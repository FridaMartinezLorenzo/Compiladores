import numpy as np

a=np.matrix