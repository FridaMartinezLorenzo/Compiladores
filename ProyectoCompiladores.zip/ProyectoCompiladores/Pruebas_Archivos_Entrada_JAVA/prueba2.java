public class prueba2 {
    public static void saludar() {
        System.out.println("Hola, mundo");
       int x = 5;
       x = 7;
    }
    @
    public static void equisde() {
        System.out.println("Hola, mundo");
        char x =  'z';
    }

    public static void main(String[] args) {
       float v = 1.234562f;
    }
}
