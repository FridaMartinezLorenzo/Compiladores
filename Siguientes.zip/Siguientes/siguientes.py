import re

class reglaProduccion:
    
    def __init__(self, b, p):
        self.base = b
        self.produccion_cadena = p
        self.produccion = []

    def getBase(self):
        return self.base

    def getProduccion(self):
        return self.produccion

    def setBase(self, b):
        self.base = b
    
    def setProduccionCadena(self, p):
        self.produccion = p
    
    def addProduccion(self, p):
        self.produccion.append(p)
        
    
    def __str__(self):
        return self.base + " -> " + self.produccion + ";"
    
#________________________________________________________________________________________________________

def obtencionSiguientes(reglasProducccion): #Recibe un arreglo de reglas de producción
    simbolos_inicial = reglasProduccion[0].getBase()
    print("Simbolo inicial: ", simbolos_inicial)
    
    desgloce_elementos_produccion = []
    pass

#_____________________________________________________________________________________________________
def desgloceElementosProduccion(reglasProduccion, listaReservadas): #Recibe una produccion
    for regla in reglasProduccion:
        #Procedemos a buscar si existen palabras reservadas en la produccion
        for pReservada in listaReservadas:
            if regla.produccion_cadena.find(pReservada) != -1:
                #Si existe una palabra reservada en la produccion, la añadimos a la lista de elementos de la produccion
                regla.addProduccion(pReservada)
        
        #En caso de que no contenga palabras reservadas se va a proceder a desglozar la produccion elemento a elemento
        for elemento in regla.produccion_cadena:
            regla.addProduccion(elemento)      
        
        print("Produccion:" )
        for elemento in regla.produccion:
            print(elemento)                  


#__________________________________________________________________________________________________________
def cargar_pReservadas(lineas):
    for linea in lineas:
        lista_pReservadas.append(linea.strip('\n'))


#__________________________________________________________________________________________________________
#script
archivo_cargado = 'palabras_reservadas.txt'
with open(archivo_cargado, 'r') as file:
    lineas = file.readlines()
    
lista_pReservadas = []
cargar_pReservadas(lineas)



#Desglozamos la regla que entre
reglaproduccion = "A -> a;"
base = reglaproduccion.split("->")[0].strip() #Se retorna el primer elemento
produccion = reglaproduccion.split("->")[1].strip() #Se retorna lo que produce

#print("Regla de produccion: ", reglaproduccion)
#print("Base: ", base)
#print("produccion: ", produccion)

reglasProduccion = []
rp = reglaProduccion(base, produccion)
reglasProduccion.append(rp)


desgloceElementosProduccion(reglasProduccion, lista_pReservadas)
obtencionSiguientes(reglasProduccion)
